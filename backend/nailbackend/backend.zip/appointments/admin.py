from django.contrib import admin
from .models import Service, Booking

admin.site.register(Service)
admin.site.register(Booking)
