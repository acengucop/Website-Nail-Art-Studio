import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import ProductCard from "../UI/ProductCard"
const BADGE_LABELS = ["Promo", "Bestseller", "New", "Limited"];

export default function ShopHighlight() {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [cart, setCart] = useState([]);
  const [, setNow] = useState(Date.now());
  const [error, setError] = useState(null);

  // --- Cart Persistent: load cart dari localStorage saat mount
  useEffect(() => {
    const savedCart = localStorage.getItem("cart");
    if (savedCart) {
      setCart(JSON.parse(savedCart));
    }
  }, []);

  // --- Cart Persistent: simpan cart ke localStorage setiap cart berubah
  useEffect(() => {
    localStorage.setItem("cart", JSON.stringify(cart));
  }, [cart]);

  // --- Promo countdown update setiap detik
  useEffect(() => {
    const interval = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(interval);
  }, []);

  // --- Optimasi Fetching: AbortController & error handling
  useEffect(() => {
    const controller = new AbortController();
    setLoading(true);
    setError(null);

    fetch("http://localhost:8000/api/products/", { signal: controller.signal })
      .then(res => {
        if (!res.ok) throw new Error("Gagal memuat produk.");
        return res.json();
      })
      .then(data => {
        setProducts(data);
        setLoading(false);
      })
      .catch((err) => {
        if (err.name !== "AbortError") {
          setError(err.message || "Terjadi kesalahan saat mengambil produk.");
          setLoading(false);
        }
      });

    return () => controller.abort();
  }, []);

  const handleAddToCart = (product) => {
    if (product.stock > 0) {
      setCart((prev) => {
        const found = prev.find(item => item.id === product.id);
        if (found) {
          return prev.map(item =>
            item.id === product.id
              ? { ...item, qty: item.qty + 1 }
              : item
          );
        }
        return [...prev, { ...product, qty: 1 }];
      });
    }
  };

  // Ambil satu produk untuk setiap badge label utama
  const filteredProducts = BADGE_LABELS
    .map(label => products.find(p => p.badge_label === label))
    .filter(Boolean); // hilangkan undefined jika tidak ada produk dengan label tsb

  // ====== RENDER UI ======
  return (
<section className="py-16" style={{ backgroundColor: "#f9cee7" }}>
      <div className="container mx-auto px-4">
        {/* ===== TITLE & DESKRIPSI ===== */}
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-3">Produk Unggulan</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Temukan produk berkualitas untuk perawatan kuku di rumah
          </p>
        </div>

        {/* ===== CART BADGE / KERANJANG ===== */}
        <div className="fixed top-8 right-8 z-50 ">
          <button
            className="relative bg-primary text-white rounded-full w-12 h-12 flex items-center justify-center shadow-lg"
            aria-label="Buka keranjang belanja"
          >
            <img
              src="online-shop.gif"
              alt="Keranjang Belanja"
              className="w-9 h-9 object-contain"
              draggable={false}
            />
            {cart.length > 0 && (
              <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full px-2 py-0.5 font-bold">
                {cart.reduce((sum, item) => sum + item.qty, 0)}
              </span>
            )}
          </button>
        </div>

        {/* ===== LOADING / ERROR / EMPTY STATE / PRODUCT GRID ===== */}
        {loading ? (
          <div className="text-center py-12 text-gray-400">Loading produk...</div>
        ) : error ? (
          <div className="text-center py-12 text-red-500">
            {error}
          </div>
        ) : filteredProducts.length === 0 ? (
          // ===== EMPTY STATE =====
          <div className="col-span-3 flex flex-col items-center justify-center py-12">
            <img
              src="/svg_empty.svg"
              alt="Produk kosong"
              className="w-40 h-40 mb-4 opacity-80"
              loading="lazy"
            />
            <p className="text-gray-400 text-lg font-semibold mb-1">
              Tidak ada produk tersedia.
            </p>
            <span className="text-gray-500">
              Coba cek kembali beberapa saat lagi.
            </span>
          </div>
        ) : (
          // ===== GRID WRAPPER AGAR SELALU DI TENGAH =====
<div className="w-full flex justify-center items-start">
  <div className={`
    grid gap-8
    w-full
    max-w-7xl
    grid-cols-1
    sm:grid-cols-2
    md:grid-cols-3
    lg:grid-cols-4
    items-stretch
  `}>
              {/* ===== MAP PRODUK KE ProductCard ===== */}
              {filteredProducts.map((product, idx) => (
                <ProductCard
                  key={product.id || idx}
                  product={product}
                  onAddToCart={handleAddToCart}
                />
              ))}
            </div>
          </div>
        )}

        {/* ===== FOOTER: TOMBOL LIHAT SEMUA PRODUK ===== */}
        <div className="text-center mt-12">
          <Link
            to="/products"
            className="inline-flex items-center justify-center px-6 py-3 bg-white border-2 border-primary text-primary font-medium rounded-button hover:bg-primary/5 transition-all whitespace-nowrap"
          >
            <span>Lihat Semua Produk</span>
            <i className="ri-arrow-right-line ri-lg ml-2"></i>
          </Link>
        </div>
      </div>
    </section>
  );
}
