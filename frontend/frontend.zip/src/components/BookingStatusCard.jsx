// components/BookingStatusCard.jsx
import React from "react";

export default function BookingStatusCard({ booking, onReupload }) {
  // Pilih warna badge sesuai status
  const statusColors = {
    pending: "bg-yellow-200 text-yellow-800",
    confirmed: "bg-green-200 text-green-800",
    waiting: "bg-blue-200 text-blue-800",
    rejected: "bg-red-200 text-red-800",
    cancelled: "bg-gray-200 text-gray-700",
    done: "bg-green-100 text-green-700",
  };

  return (
    <div className="border rounded-xl p-4 flex justify-between items-center bg-white shadow-sm transition hover:shadow-lg">
      <div>
        <div className="font-semibold text-lg mb-1">{booking.service?.name || "-"}</div>
        <div className="text-sm text-gray-500 mb-1">
          {booking.date} {booking.time}
        </div>
        <div className="flex gap-2 mt-2">
          <span className={`px-2 py-1 rounded-full text-xs font-semibold ${statusColors[booking.status] || "bg-gray-100 text-gray-700"}`}>
            {booking.status}
          </span>
          <span className={`px-2 py-1 rounded-full text-xs font-semibold ${statusColors[booking.payment_status] || "bg-gray-100 text-gray-700"}`}>
            {booking.payment_status}
          </span>
        </div>
      </div>
      {booking.payment_status === "rejected" && onReupload && (
        <button
          className="ml-4 bg-blue-500 text-white px-3 py-1 rounded shadow hover:bg-blue-600 transition"
          onClick={() => onReupload(booking.id)}
        >
          Upload Ulang Bukti
        </button>
      )}
    </div>
  );
}
