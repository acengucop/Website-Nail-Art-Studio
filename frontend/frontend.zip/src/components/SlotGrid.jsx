export default function SlotGrid({ slots, selected, onSelect }) {
  return (
    <div className="grid grid-cols-3 gap-3">
      {Object.entries(slots).map(([jam, status]) => (
        <button
          key={jam}
          disabled={status !== "available"}
          onClick={() => onSelect(jam)}
          className={`rounded p-2 text-lg font-bold
            ${status === "booked" && "bg-red-300"}
            ${status === "expired" && "bg-gray-200"}
            ${status === "available" && "bg-green-400 hover:bg-green-500"}
            ${selected === jam && "ring-4 ring-blue-400"}
          `}
        >
          {jam}
        </button>
      ))}
    </div>
  );
}
