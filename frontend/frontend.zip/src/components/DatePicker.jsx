// components/DatePicker.jsx
import ReactDatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";

export default function DatePicker({ value, onChange, label }) {
  return (
    <div className="flex flex-col gap-1 mb-2">
      {label && <label className="font-medium text-sm">{label}</label>}
      <ReactDatePicker
        selected={value ? new Date(value) : null}
        onChange={date => onChange(date.toISOString().slice(0, 10))}
        dateFormat="yyyy-MM-dd"
        minDate={new Date()}
        className="border rounded px-3 py-2 outline-blue-400"
        placeholderText="Pilih tanggal"
      />
    </div>
  );
}
