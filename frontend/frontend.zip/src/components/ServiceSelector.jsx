import { useEffect, useState } from "react";
import axios from "../utils/axios";

export default function ServiceSelector({ value, onChange }) {
  const [services, setServices] = useState([]);
  useEffect(() => {
    axios.get("/services/").then(res => setServices(res.data));
  }, []);
  return (
    <select value={value} onChange={e => onChange(e.target.value)}>
      <option value="">Pilih layanan</option>
      {services.map(s => (
        <option value={s.id} key={s.id}>
          {s.name} - Rp {Number(s.price).toLocaleString()}
        </option>
      ))}
    </select>
  );
}
