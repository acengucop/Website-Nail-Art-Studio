import { useEffect, useState } from "react";
import axios from "../utils/axios";

export default function PaymentMethodSelector({ value, onChange }) {
  const [methods, setMethods] = useState([]);
  useEffect(() => {
    axios.get("/payment-methods/").then(res => setMethods(res.data));
  }, []);
  return (
    <div className="flex flex-wrap gap-6">
      {methods.map(m => (
        <label key={m.id} className="cursor-pointer flex flex-col items-center">
          <input
            type="radio"
            name="payment_method"
            checked={value === m.id}
            onChange={() => onChange(m.id)}
          />
          <img src={m.qr_image} alt={m.name} className="h-28 w-28 object-contain" />
          <span className="mt-2">{m.name}</span>
        </label>
      ))}
    </div>
  );
}
