import { useEffect, useState } from "react";
import axios from "../utils/axios";
import { useNavigate } from "react-router-dom";
import BookingStatusCard from "../components/BookingStatusCard"; // Import komponen baru

export default function MyAppointments() {
  const [data, setData] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    axios.get("/booking/my/").then(res => setData(res.data));
  }, []);

  // Handler untuk upload ulang bukti pembayaran
  const handleReupload = id => {
    navigate(`/booking-payment/${id}`);
  };

  return (
    <div>
      <h1 className="font-bold text-xl mb-4">Booking Saya</h1>
      <div className="space-y-4">
        {data.map(booking => (
          <BookingStatusCard
            key={booking.id}
            booking={booking}
            onReupload={handleReupload}
          />
        ))}
      </div>
    </div>
  );
}
