// src/pages/BookingPage.jsx
import { useState, useEffect, useCallback } from "react";
import axios from "../utils/axios";
import ServiceSelector from "../components/ServiceSelector";
import SlotGrid from "../components/SlotGrid";
import DatePicker from "../components/DatePicker";
import PaymentMethodSelector from "../components/PaymentMethodSelector";
import { useNavigate } from "react-router-dom";

export default function BookingPage() {
  const [service, setService] = useState("");
  const [date, setDate] = useState("");
  const [slots, setSlots] = useState({});
  const [selectedSlot, setSelectedSlot] = useState("");
  const [paymentMethod, setPaymentMethod] = useState("");
  const [file, setFile] = useState(null);
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  // Fetch slot availability
  const fetchSlots = useCallback(async () => {
    if (!service || !date) {
      setSlots({});
      return;
    }
    try {
      const { data } = await axios.get("/booking/availability/", {
        params: { date, service_id: service },
      });
      setSlots(data);
    } catch {
      setSlots({});
    }
  }, [service, date]);

  useEffect(() => {
    fetchSlots();
  }, [fetchSlots]);

  // Validate before submission
  const isValid = service && date && selectedSlot && paymentMethod && file;

  // Handle booking & proof upload
  const handleBooking = async (e) => {
    e.preventDefault();
    if (!isValid) {
      alert("Semua field dan bukti pembayaran harus dipilih.");
      return;
    }

    setLoading(true);
    const formData = new FormData();
    formData.append("service_id", service);
    formData.append("date", date);
    formData.append("time", selectedSlot);
    formData.append("payment_method_id", paymentMethod);
    formData.append("payment_proof", file);

    try {
      await axios.post("/booking/create/", formData);
      alert("Booking berhasil dikirim, tunggu verifikasi admin.");
      navigate("/my-appointments");
    } catch (err) {
      const msg =
        err.response?.data?.error ||
        err.response?.data?.detail ||
        err.message ||
        "Terjadi kesalahan.";
      alert("Gagal booking: " + msg);
    } finally {
      setLoading(false);
    }
  };

  return (
    <form
      onSubmit={handleBooking}
      className="max-w-xl mx-auto mt-8 p-6 space-y-6 bg-white rounded-lg shadow"
    >
      <h1 className="text-2xl font-bold text-center">Booking Nail Art</h1>

      <ServiceSelector value={service} onChange={setService} />

      <DatePicker value={date} onChange={setDate} label="Pilih Tanggal Booking" />

      {Object.keys(slots).length > 0 && (
        <SlotGrid
          slots={slots}
          selected={selectedSlot}
          onSelect={setSelectedSlot}
        />
      )}

      <PaymentMethodSelector value={paymentMethod} onChange={setPaymentMethod} />

      <div>
        <label className="block text-sm font-medium mb-1">
          Unggah Bukti Pembayaran
        </label>
        <input
          type="file"
          accept="image/*"
          onChange={(e) => setFile(e.target.files[0])}
          className="block w-full text-sm text-gray-700"
        />
      </div>

      <button
        type="submit"
        disabled={!isValid || loading}
        className={`w-full py-3 text-white font-semibold rounded-lg transition ${
          loading
            ? "bg-gray-400 cursor-not-allowed"
            : "bg-pink-500 hover:bg-pink-600"
        }`}
      >
        {loading ? "Mengirim..." : "Booking & Upload Bukti"}
      </button>
    </form>
  );
}
